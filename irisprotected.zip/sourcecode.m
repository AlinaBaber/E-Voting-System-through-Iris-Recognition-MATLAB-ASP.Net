% 
% IRIS RECOGNITION SYSTEM
%
% In order to obtain the complete source code please visit
% 
% http://www.advancedsourcecode.com/iris.asp
%
% A small donation (just 30 Euros, less than 42 U.S. Dollars) is required.
% 
% Date              Release           Major features
% 
% 2006.04.23        1.0               - Decreased execution time: 94% faster
%                                       than original code (Libor Masek's
%                                       implementation)
%                                     - Matching module
%                                     - Iris recognition
%                                     - Interactive and intuitive GUI
%                                     - C code included
%
%  References:
%  Libor Masek, Peter Kovesi. MATLAB Source Code for a Biometric Identification 
%  System Based on Iris Patterns. The School of Computer Science and Software Engineering, 
%  The University of Western Australia. 2003.
%
%  The original source code is available at
%  http://www.csse.uwa.edu.au/~pk/studentprojects/libor/iriscode.zip
%
%  Libor Masek's dissertation is available at
%  http://www.csse.uwa.edu.au/~pk/studentprojects/libor/LiborMasekThesis.pdf
%
%  All tests were performed with CASIA Iris Image Database available at 
%  http://www.sinobiometrics.com
%
%
% For more informations please email me luigi.rosa@tiscali.it
% 
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila - ITALY 
% email luigi.rosa@tiscali.it
% mobile +39 3207214179 
% website http://www.advancedsourcecode.com
%
%